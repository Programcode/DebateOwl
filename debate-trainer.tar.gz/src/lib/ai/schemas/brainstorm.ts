// src/lib/ai/schemas/brainstorm.ts
import { z } from 'zod';

export const BrainstormInputSchema = z.object({
  motion: z.string().min(1, 'Motion is required'),
  side: z.enum(['pro', 'con', 'both']),
  existingIdeas: z.string(),
  constraints: z.object({
    ethicalRedLines: z.array(z.string()),
    allowedSources: z.array(z.string()),
    timeLimit: z.number().optional(),
  }),
  outputMode: z.enum(['mindmap', 'buckets', 'topfive']),
});

export type BrainstormInput = z.infer<typeof BrainstormInputSchema>;

export const IdeaSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  side: z.enum(['pro', 'con', 'neutral']),
  strength: z.enum(['strong', 'moderate', 'weak']),
  tradeoffs: z.array(z.string()),
  relatedTo: z.array(z.string()),
});

export const BucketSchema = z.object({
  name: z.string(),
  ideas: z.array(IdeaSchema),
  keyInsight: z.string(),
});

export const BrainstormOutputSchema = z.object({
  clarifyingQuestions: z.array(z.string()).optional(),
  needsMoreInfo: z.boolean(),
  mindmap: z.array(z.object({
    category: z.string(),
    items: z.array(IdeaSchema),
  })).optional(),
  buckets: z.array(BucketSchema).optional(),
  topFive: z.array(z.object({
    rank: z.number(),
    idea: IdeaSchema,
    whyTop: z.string(),
  })).optional(),
  nextSteps: z.array(z.string()),
  warningsAndTradeoffs: z.array(z.string()),
});

export type BrainstormOutput = z.infer<typeof BrainstormOutputSchema>;
export type Idea = z.infer<typeof IdeaSchema>;
